# CRUMPLED-BALLS-PART-1

## Crumpled Paper is an inspiration of Paper Trash.

### Output Link :  https://rajdeepjaiswal.github.io/CRUMPLED-BALLS-PART-1/
